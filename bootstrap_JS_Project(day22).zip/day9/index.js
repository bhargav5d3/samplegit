
function validate(){
    alert("Form going under validation");
}